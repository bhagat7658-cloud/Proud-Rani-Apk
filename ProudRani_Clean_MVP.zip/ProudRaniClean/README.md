# Proud Rani — Gen-Z of JKL

Free Android MVP for the Proud Rani women-safety movement.

## Current MVP
- Large SOS button
- Location permission + last known location
- SOS message prepared with Google Maps location link
- Emergency 112 button
- Core-team call buttons
- WhatsApp helpline button
- Incident/report sharing

## Important
The SOS flow opens the SMS composer or WhatsApp with a prepared message. It does **not** silently send messages. For immediate danger, call 112 first.

## Build
Open this folder in Android Studio and build `app`, or push to GitHub and let `.github/workflows/build.yml` create the debug APK artifact.

The project deliberately uses Java 17 consistently, avoiding the previous Java 1.8 vs Kotlin 17 JVM-target mismatch.
