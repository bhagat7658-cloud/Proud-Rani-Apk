package com.genzofjkl.proudrani;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

public class MainActivity extends AppCompatActivity {
    private static final String ANMOL = "9055501242";
    private static final String AAGRIYA = "9622191919";
    private static final String WHATSAPP = "919055501242";
    private FusedLocationProviderClient fusedLocation;

    private final ActivityResultLauncher<String[]> locationPermission =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), result -> {
                boolean granted = Boolean.TRUE.equals(result.get(Manifest.permission.ACCESS_FINE_LOCATION))
                        || Boolean.TRUE.equals(result.get(Manifest.permission.ACCESS_COARSE_LOCATION));
                if (granted) sendSosWithLocation();
                else openSosFallback();
            });

    private final ActivityResultLauncher<String> callPermission =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
                if (granted) callNumber("112");
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fusedLocation = LocationServices.getFusedLocationProviderClient(this);

        findViewById(R.id.btnSos).setOnClickListener(v -> confirmSos());
        findViewById(R.id.btn112).setOnClickListener(v -> callNumber("112"));
        findViewById(R.id.btnAnmol).setOnClickListener(v -> callNumber(ANMOL));
        findViewById(R.id.btnAagriya).setOnClickListener(v -> callNumber(AAGRIYA));
        findViewById(R.id.btnWhatsApp).setOnClickListener(v -> openWhatsApp());
        findViewById(R.id.btnReport).setOnClickListener(v -> shareReport());
    }

    private void confirmSos() {
        new AlertDialog.Builder(this)
                .setTitle("Send SOS?")
                .setMessage("Proud Rani will prepare an emergency message with your current location. In immediate danger, call 112 first.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("CONTINUE", (d, w) -> requestLocation())
                .show();
    }

    private void requestLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            sendSosWithLocation();
        } else {
            locationPermission.launch(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION});
        }
    }

    private void sendSosWithLocation() {
        try {
            fusedLocation.getLastLocation().addOnSuccessListener(location -> {
                String message;
                if (location != null) {
                    message = "SOS — I need help. My location: https://maps.google.com/?q="
                            + location.getLatitude() + "," + location.getLongitude();
                } else {
                    message = "SOS — I need help. My current location could not be obtained. Please call me immediately.";
                }
                Intent send = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + ANMOL));
                send.putExtra("sms_body", message);
                try { startActivity(send); }
                catch (Exception e) { openWhatsAppWithMessage(message); }
            }).addOnFailureListener(e -> openSosFallback());
        } catch (SecurityException e) {
            openSosFallback();
        }
    }

    private void openSosFallback() {
        String message = "SOS — I need help. Please contact me immediately.";
        openWhatsAppWithMessage(message);
    }

    private void openWhatsApp() {
        String url = "https://wa.me/" + WHATSAPP + "?text=" + Uri.encode("Hello Proud Rani, I need help.");
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { Toast.makeText(this, "WhatsApp is not available", Toast.LENGTH_SHORT).show(); }
    }

    private void openWhatsAppWithMessage(String message) {
        String url = "https://wa.me/" + WHATSAPP + "?text=" + Uri.encode(message);
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }
    }

    private void callNumber(String number) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            startActivity(new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + number)));
        } else {
            if (number.equals("112")) callPermission.launch(Manifest.permission.CALL_PHONE);
            else startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + number)));
        }
    }

    private void shareReport() {
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, "Proud Rani incident report:\n\nWhat happened:\n\nWhen/where:\n\nWhat support I need:");
        startActivity(Intent.createChooser(send, "Choose where to report/share"));
    }
}
